// Exporta funciones invocadas en otroos modulos

// Variables

// funciones
void inic_Timer7 ();
void cronometro();
void inic_crono();
void Delay_ms(int milisegundos);
void Delay_us(int microsegundos);
void inic_Timer5();