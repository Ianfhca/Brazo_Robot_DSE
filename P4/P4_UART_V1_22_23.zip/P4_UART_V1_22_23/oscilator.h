
// funcion que utiliza el main

void inic_oscilator ();
