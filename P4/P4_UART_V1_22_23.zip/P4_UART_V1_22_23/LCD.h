
// Funciones
	
void lcd_cmd(char cmd);	
void lcd_data(char data);
void inic_LCD();
void puts_lcd (unsigned char *data, unsigned char count);
void line_1();
void line_2();
void SM();
