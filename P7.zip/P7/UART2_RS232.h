// Funciones que se utilizan desde otros modulos
void inic_UART2 ();



