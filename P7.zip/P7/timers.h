// Exporta funciones invocadas en otroos modulos

// Variables
extern unsigned int flag_T6;

// funciones
void inic_Timer7 ();
void inic_Timer5();
void inic_Timer3();
void inic_Timer2();
void cronometro();
void inic_crono();
void Delay_ms(int milisegundos);
void Delay_us(int microsegundos);
void crono();
void comprobar_inic_crono();