
// funciones
void conversion_tiempo (unsigned char * dir, unsigned int val);
void conversion_4digitos (unsigned char * dir, unsigned int val);