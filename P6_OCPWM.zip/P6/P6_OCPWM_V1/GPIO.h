// declaracion de las funciones relacionadas con los pines GPIO
// que se usan en otros modulos

void inic_leds();
void inic_pulsadores();

