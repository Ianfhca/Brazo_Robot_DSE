// Variables y funciones exportadas para utilizarlas desde otros modulos

// VARIABLES
//=========================================================
extern unsigned int DUTY_MIN;
extern unsigned int DUTY_MAX;
extern unsigned int flag_servo;
extern unsigned int modo_control;

// FUNCIONES
//=========================================================
void inic_OC1 ();
void mostrar_OC1();
void relacion_adc_pwm();
