// Variables y funciones exportadas para utilizarlas desde otros modulos

// VARIABLES
//=========================================================
extern unsigned int DUTY_MIN;
extern unsigned int DUTY_MAX;
extern unsigned int DUTY;
extern unsigned int flag_servo;
extern unsigned int modo_control;

// FUNCIONES
//=========================================================
void mostrar_duty();
void relacion_adc_pwm();
