
// Funciones que se llaman desde otros modulos


void inic_ADC1 ();
void comienzo_muestreo ();
void recoger_valorADC1 ();


